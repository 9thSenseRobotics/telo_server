<?php

require_once ('officebot-include.php');

function is_valid_create_command($cmd)
// make sure it's a command we understand
{ 
	switch ($cmd)
	{
		case 'f':
		case 'b':
		case 'l':
		case 'r':
		case 's':
			return ($cmd);
		default: 
			return (false);
	}
}

function is_valid_pantilt_command($cmd)
// make sure it's a command we understand
{ 
	switch ($cmd)
	{
		case 'u':
		case 'd':
		case 'l':
		case 'r':
			return ($cmd);
		default: 
			return (false);
	}
}


function robot_command($cmd)
{
	global $conn, $createActionTable;
	
	if (is_valid_create_command($cmd))
	{
		mysql_query("update $createActionTable set command =  '$cmd', last_update = " . microtime (true)); 
	} else {
		syslog (LOG_NOTICE, "invalid robot command issued: $cmd");
	}
}

function pantilt_command($cmd)
{
	global $conn, $pantiltActionTable;
	
	if (is_valid_pantilt_command($cmd))
	{
		$q = "update $pantiltActionTable set command =  '$cmd', last_update = " . microtime (true);
		mysql_query($q);
	} else {
		syslog (LOG_NOTICE, "invalid pantilt command issued: $cmd");
	}
}

function pantilt_up() 
{
	pantilt_command ('u');
}

function pantilt_down() 
{
	pantilt_command ('d');
}

function pantilt_left() 
{
	pantilt_command ('l');
}

function pantilt_right() 
{
	pantilt_command ('r');
}



function robot_forward() 
{
	robot_command('f');
}

function robot_backward() 
{
	robot_command('b');
}
function robot_left() 
{
	robot_command('l');
}
function robot_right() 
{
	robot_command('r');
}
function robot_stop() 
{
	robot_command('s');
}

	header("Content-type: text/json");
	if (isset ($_REQUEST['cmd']))
	{
		switch ($_REQUEST['cmd'])
	//	switch ('l')
		{
			case 'f':
				robot_forward();
				$retval = 'f';
				break;
			case 'b':
				robot_backward();
				$retval = 'b';
				break;
			case 'l':
				robot_left();
				$retval = 'l';
				break;
			case 'r':
				robot_right();
				$retval = 'r';
				break;
			case 's':
				robot_stop();
				$retval = 's';
				break;
			default: 
				$retval = "none";
				break;
		}
	} 
	if (isset ($_REQUEST['pantilt']))
	{	
		switch ($_REQUEST['pantilt'])
		{
			case 'l': // pan left
				pantilt_left();
				break;
			case 'r': // pan right
				pantilt_right();
				break;
			case 'u': // tilt up
				pantilt_up();
				break;
			case 'd': // tilt down
				pantilt_down();
				break;
			default:
				$cmd = NULL;
				break;
		}
	}
	echo (json_encode(array('createRet' => $retval, 'arduinoRet' => $_REQUEST['pantilt'])));
?>
