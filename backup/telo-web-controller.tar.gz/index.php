<html>
<head>

<title>WebCam</title>
<style type="text/css">
	div#container {
		width: 100%;
	}
	div#nav-video {
		width: 25%;
		float: left;
		margin: 15px;
		padding: 10px;
	}
	div#nav-controls {
		width: 25%;
		float: left;
		margin: auto;
		padding: 10px;
		text-align: center;
	}
	div#pri-video {
		width: 25%;
		float: left;
		margin: 15px;
		padding: 10px;
	}
	p.nav-title {
		font-size: 32px;
		color: #bbbbbb;
	}	
	.centered {
		text-align: center;
	}
	img.control-button {
		width: 32;
		height: 32;
	
	
</style>
<script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.15.custom.min.js"></script>
<script type="text/javascript">

function send_create_command (cmd)
{
	$.post('officebot-controller.php?cmd=' + cmd, function(data) {
		$('span.createresult').html(data.createRet);
	});
}

function send_pantilt_command (cmd)
{
	$.post('officebot-controller.php?pantilt=' + cmd, function(data) {
		$('span.arduinoresult').html(data.arduinoRet);
	});
}

function pantilt_up()
{
	send_pantilt_command('u');
}

function pantilt_down()
{
	send_pantilt_command('d');
}

function pantilt_left()
{
	send_pantilt_command('l');
}

function pantilt_right()
{
	send_pantilt_command('r');
}


function create_forward()
{
	send_create_command('f');
}

function create_backward()
{
	send_create_command('b');
}

function create_left()
{
	send_create_command('l');
}

function create_right()
{
	send_create_command('r');
}

function create_stop()
{
	send_create_command('s');
}


	$(document).ready(function() {
		action = null;
		$("#button-create-forward").mousedown(function() {
			console.log('forward');
			action = setInterval(create_forward, 1000);
		}).bind('mouseup mouseleave', function () {
			clearInterval(action);
			create_stop();
		});
		$("#button-create-backward").mousedown(function() {
			console.log('backward');
			action = setInterval(create_backward, 1000);
		}).bind('mouseup mouseleave', function () {
			clearInterval(action);
			create_stop();
		});
		$("#button-create-left").mousedown(function() {
			console.log('left');
			action = setInterval(create_left, 1000);
		}).bind('mouseup mouseleave', function () {
			clearInterval(action);
			create_stop();
		});
		$("#button-create-right").mousedown(function() {
			console.log('right');
			action = setInterval(create_right, 1000);
		}).bind('mouseup mouseleave', function () {
			clearInterval(action);
			create_stop();
		});

		$("#button-pantilt-up").mousedown(function() {
			console.log('pantilt-up');
			action = setInterval(pantilt_up, 300);
		}).bind('mouseup mouseleave', function () {
			clearInterval(action);
		});
		
		$("#button-pantilt-down").mousedown(function() {
			console.log('pantilt-down');
			action = setInterval(pantilt_down, 300);
		}).bind('mouseup mouseleave', function () {
			clearInterval(action);
		});

		$("#button-pantilt-left").mousedown(function() {
			console.log('pantilt-left');
			action = setInterval(pantilt_left, 300);
		}).bind('mouseup mouseleave', function () {
			clearInterval(action);
		});

		$("#button-pantilt-right").mousedown(function() {
			console.log('pantilt-right');
			action = setInterval(pantilt_right, 300);
		}).bind('mouseup mouseleave', function () {
			clearInterval(action);
		});
				

		$("#button-create-stop").mousedown(function() {
			console.log('stop');
			create_stop();
		});
		setInterval(function () {
			d = new Date();		
//			$("#navcam-image").attr("src", "http://199.101.129.90:8991/?action=snapshot&d=" + d.getTime());
			$("#navcam-image").attr("src", "8992.jpg&d=" + d.getTime());
		},200);
		setInterval(function () {
			d = new Date();		
//			$("#pricam-image").attr("src", "http://199.101.129.90:8992/?action=snapshot&d=" + d.getTime());
			$("#navcam-image").attr("src", "8992.jpg&d=" + d.getTime());
		},200);
	 });
</script>
<link href="css/ui-lightness/jquery-ui-1.8.15.custom.css" rel="stylesheet" type="text/css"/>


</head>
<body> 
 <div id="container">
	<div id="nav-video">
		<img id="navcam-image" src="http://199.101.129.90:8991/?action=snapshot" />
	</div>
	<div id="pri-video">
		<img id="pricam-image" src="http://199.101.129.90:8992/?action=snapshot" />
	</div>
	<div id="nav-controls">
		<div>
			<table border="0">
				<tr>
					<th colspan="3">Navigation</th>
				</tr>
				<tr>
					<td class="centered" colspan="3"> <img id="button-create-forward" class="control-button" src="images/forward.png" /></td>
				</tr>
				<tr>
					<td class="centered"> <img id="button-create-left" class="control-button" src="images/left.png" /></td>
					<td class="centered"> <img id="button-create-stop" class="control-button" src="images/stop.png" /></td>
					<td class="centered"> <img id="button-create-right" class="control-button" src="images/right.png" /></td>
				</tr>
				<tr>
					<td class="centered" colspan="3"> <img id="button-create-backward" class="control-button" src="images/backward.png" /></td>
				</tr>
			</table>

			<table border="0">
				<tr>
					<th colspan="3">Pan/tilt</th>
				</tr>
				<tr>
					<td class="centered" colspan="3"> <img id="button-pantilt-up" class="control-button" src="images/forward.png" /></td>
				</tr>
				<tr>
					<td class="centered"> <img id="button-pantilt-left" class="control-button" src="images/left.png" /></td>
					<td class="centered"> <img id="button-pantilt-stop" class="control-button" src="images/stop.png" /></td>
					<td class="centered"> <img id="button-pantilt-right" class="control-button" src="images/right.png" /></td>
				</tr>
				<tr>
					<td class="centered" colspan="3"> <img id="button-pantilt-down" class="control-button" src="images/backward.png" /></td>
				</tr>
			</table>

		</div>
<!--		Create Result: <span class="createresult">N/A</span><br />
		Arduino Result: <span class="arduinoresult">N/A</span><br />
-->
	</div>
</div>


</body> 
</html>

</body>
</html>
